from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Tuple

import psycopg
from psycopg.rows import dict_row

try:
    from app.core.config import DB_CONFIG  
except Exception:
    DB_CONFIG: Dict[str, str] = {
        "host": os.getenv("DB_HOST", "127.0.0.1"),
        "user": os.getenv("DB_USER", "spaceai"),
        "password": os.getenv("DB_PASSWORD", ""),
        "database": os.getenv("DB_NAME", "obsidian_db"),
        "port": os.getenv("DB_PORT", "6432"),
    }

_CONN: Optional[psycopg.Connection[Dict[str, Any]]] = None

def _new_connection(autocommit: bool = True) -> psycopg.Connection[Dict[str, Any]]:
    return psycopg.connect(
        host=DB_CONFIG.get("host", "127.0.0.1"),
        user=DB_CONFIG.get("user", "spaceai"),
        password=DB_CONFIG.get("password", ""),
        dbname=DB_CONFIG.get("database", "obsidian_db"),
        port=int(DB_CONFIG.get("port", os.getenv("DB_PORT", "6432"))),
        autocommit=autocommit,
        row_factory=dict_row,
    )

def get_connection(autocommit: bool = True) -> psycopg.Connection[Dict[str, Any]]:
    return _new_connection(autocommit=autocommit)

def _ensure_conn() -> psycopg.Connection[Dict[str, Any]]:
    global _CONN
    try:
        if _CONN is None or _CONN.closed:
            _CONN = _new_connection(autocommit=True)
    except Exception:
        _CONN = _new_connection(autocommit=True)
    return _CONN

def get_cursor() -> psycopg.Cursor[Dict[str, Any]]:
    conn = _ensure_conn()
    return conn.cursor()

def commit() -> None:
    try:
        if _CONN and not _CONN.closed and not _CONN.autocommit:
            _CONN.commit()
    except Exception:
        pass

def rollback() -> None:
    try:
        if _CONN and not _CONN.closed and not _CONN.autocommit:
            _CONN.rollback()
    except Exception:
        pass

def close_connection() -> None:
    global _CONN
    try:
        if _CONN and not _CONN.closed:
            _CONN.close()
    finally:
        _CONN = None

def fetch_one(sql: str, params: Tuple[Any, ...] = ()) -> Optional[Dict[str, Any]]:
    conn = _new_connection(autocommit=True)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            row = cur.fetchone()
            return dict(row) if row else None
    finally:
        conn.close()

def fetch_all(sql: str, params: Tuple[Any, ...] = ()) -> List[Dict[str, Any]]:
    conn = _new_connection(autocommit=True)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
            return list(rows) if rows else []
    finally:
        conn.close()

def execute(sql: str, params: Tuple[Any, ...] = (), return_id: Optional[str] = None):
    conn = _new_connection(autocommit=True)
    try:
        with conn.cursor() as cur:
            statement = sql
            if return_id:
                statement = f"{sql.rstrip().rstrip(';')} RETURNING {return_id}"
            cur.execute(statement, params)
            if return_id:
                row = cur.fetchone()
                return row[return_id] if row else None
            return True
    finally:
        conn.close()
